import ExamPortalTeacherDashboard from "./ExamPortalTeacherDashboard";

export default ExamPortalTeacherDashboard;
