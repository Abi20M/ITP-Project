import ExamPortalHero from "./ExamPortalHero";

export default ExamPortalHero;
