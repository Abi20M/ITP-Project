/// <reference types="react-scripts" />
declare module '*mp3';
