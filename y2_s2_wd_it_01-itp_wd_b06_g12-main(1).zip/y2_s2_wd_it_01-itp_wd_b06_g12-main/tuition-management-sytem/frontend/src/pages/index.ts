import {
  ExamPortal,
  StudentExamPortalDashboard,
  StudentExamPortalLogin,
  TeacherExamPortalDashboard,
  TeacherExamPortalLogin,
} from "./ExamPortal";

export {
  ExamPortal,
  StudentExamPortalDashboard,
  StudentExamPortalLogin,
  TeacherExamPortalDashboard,
  TeacherExamPortalLogin,
};
