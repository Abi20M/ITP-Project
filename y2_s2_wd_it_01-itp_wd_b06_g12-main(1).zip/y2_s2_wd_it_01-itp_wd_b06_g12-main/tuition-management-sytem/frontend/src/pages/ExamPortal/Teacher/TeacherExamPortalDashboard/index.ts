import TeacherExamPortalDashboard from './TeacherExamPortalDashboard';
export default TeacherExamPortalDashboard;