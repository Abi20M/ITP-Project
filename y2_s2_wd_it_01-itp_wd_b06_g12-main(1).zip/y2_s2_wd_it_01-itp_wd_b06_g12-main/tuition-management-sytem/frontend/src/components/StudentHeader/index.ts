import StudentHeader from "./StudentHeader";

export default StudentHeader;
