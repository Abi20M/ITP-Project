import MyExams from "./MyExams";

export default MyExams;
