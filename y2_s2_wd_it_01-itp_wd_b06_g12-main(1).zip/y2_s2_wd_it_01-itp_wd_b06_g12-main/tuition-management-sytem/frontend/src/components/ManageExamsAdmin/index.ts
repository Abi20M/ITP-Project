import ManageExamsAdmin from "./ManageExamsAdmin";

export default ManageExamsAdmin;
