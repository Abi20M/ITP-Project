import TeacherExamPortalDashboard from "./TeacherExamPortalDashboard";
import TeacherExamPortalLogin from "./TeacherExamPortalLogin";

export { TeacherExamPortalDashboard, TeacherExamPortalLogin };
