import TeacherExamPortalLogin from './TeacherExamPortalLogin';
export default TeacherExamPortalLogin;