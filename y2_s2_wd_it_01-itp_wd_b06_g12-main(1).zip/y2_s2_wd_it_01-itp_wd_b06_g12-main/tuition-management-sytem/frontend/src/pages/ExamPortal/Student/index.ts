import StudentExamPortalDashboard from "./StudentExamPortalDashboard";
import StudentExamPortalLogin from "./StudentExamPortalLogin";

export { StudentExamPortalDashboard, StudentExamPortalLogin };