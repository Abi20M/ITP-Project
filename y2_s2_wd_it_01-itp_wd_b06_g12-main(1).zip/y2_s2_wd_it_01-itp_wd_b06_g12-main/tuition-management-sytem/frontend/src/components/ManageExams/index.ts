import ManageExams from "./ManageExams";

export default ManageExams;
