import TeacherHeader from "./TeacherHeader";

export default TeacherHeader;
