import StudentExamPortalDashboard from './StudentExamPortalDashboard';

export default StudentExamPortalDashboard;