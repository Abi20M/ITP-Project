import mongoose from "mongoose";

// export const classDetails = {
//   id : "CLS-002",
//   name : "IT with vidath chathutanga",
//   teacher: "vidath",
//   subject: "ET",
//   day : "Monday",
//   time : "2.00 AM",
//   students : []
// };
// const obj1 = {
//   hallID : "HLS-001",
//   capacity : 200
// }
// const obj2 = {
//   hallID : "HLS-002",
//   capacity : 500
// }

// const obj3 = {
//   hallID : "HLS-003",
//   capacity : 100,
// }

// const obj4 = {
//   hallID : "HLS-004",
//   capacity : 150
// }

// const obj5 = {
//   hallID : "HLS-005",
//   capacity : 1000
// }

// const obj6 = {
//   hallID : "HLS-006",
//   capacity : 300
// }

// const obj7 = {
//   hallID : "HLS-007",
//   capacity : 250
// }

// const obj8 = {
//   hallID : "HLS-008",
//   capacity : 100
// }

// const obj9 = {
//   hallID : "HLS-009",
//   capacity : 700
// }

// const obj10 = {
//   hallID : "HLS-010",
//   capacity : 200
// }
// export const Hall1=[
//   // obj1,
//   // obj2,
//   // obj3,
//   // obj4,
//   // obj5,
//   // obj6,
//   // obj7,
//   // obj8,
//   // obj9,
//   // obj10
// ]

export const admin = {
  id : "ADM-001",
  name : "Vidura Chathuranga",
  email : "vidura@gmail.com",
  address : "No 84, Wendala, Ruwanwella",
  telephone : "071-2906815",
  password : "$2y$10$QVmg.bwTBIVIoirDdmP7DuVb8YbQ9FHYKJJIgco.DOitbSRDpNWS2"
}